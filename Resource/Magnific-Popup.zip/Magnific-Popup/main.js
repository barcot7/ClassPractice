jQuery(document).ready(function($){

	$(".video-play-btn").magnificPopup({
		type: 'video'
	});

});

